import type { APIRoute } from 'astro';

const VALID_EMAIL = 'sibgo1919@gmail.com';
const VALID_PASSWORD = '199772Sk.';

export const POST: APIRoute = async ({ request, cookies, redirect }) => {
  const formData = await request.formData();
  const email = formData.get('email');
  const password = formData.get('password');

  if (email === VALID_EMAIL && password === VALID_PASSWORD) {
    cookies.set('isAdmin', 'true', {
      path: '/',
      maxAge: 60 * 60 * 24 * 7, // 1 week
      httpOnly: true,
      secure: true,
      sameSite: 'strict'
    });
    return redirect('/');
  }

  return redirect('/login?error=ایمیل یا رمز عبور اشتباه است');
};