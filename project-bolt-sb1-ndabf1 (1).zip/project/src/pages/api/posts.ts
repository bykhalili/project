import type { APIRoute } from 'astro';
import { writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createSlug } from '../../utils/slugify';

export const POST: APIRoute = async ({ request }) => {
  try {
    const formData = await request.formData();
    const title = formData.get('title') as string;
    const content = formData.get('content') as string;
    const image = formData.get('image') as string;

    if (!title || !content) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'عنوان و محتوا الزامی هستند' 
        }),
        {
          status: 400,
          headers: { 'Content-Type': 'application/json' },
        }
      );
    }

    const slug = createSlug(title);
    const date = new Date().toISOString().split('T')[0];
    
    const postContent = `---
title: "${title}"
excerpt: "${content.slice(0, 150)}..."
publishDate: ${date}
image: "${image || ''}"
views: 0
---

${content}`;

    const filePath = join(process.cwd(), 'src', 'content', 'blog', `${slug}.mdx`);
    await writeFile(filePath, postContent, 'utf-8');

    return new Response(
      JSON.stringify({ success: true, slug }), 
      {
        status: 201,
        headers: { 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error creating post:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: 'خطا در ایجاد مقاله' 
      }),
      {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      }
    );
  }
};